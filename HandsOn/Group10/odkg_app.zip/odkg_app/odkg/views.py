from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from rdflib import Graph, Namespace, Literal
from rdflib.namespace import RDF, RDFS
from rdflib.plugins.sparql import prepareQuery
# Create your views here.

def home(request):
    g = Graph()
    g.parse("triples.nt", format="ttl")

    #QUERY TO OBTAIN GASTOS OF EACH CENTRO
    query_all_elements = prepareQuery('''
        SELECT DISTINCT ?z ?y
        WHERE
        {
        ?x <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://group10.com/ontology/Gastos>.
        ?x <http://group10.com/ontology/tieneCentro> ?y.
        ?x <http://purl.org/cerif/frapo/hasCost> ?z
        }
    '''
    )

    centrosGastos = {}
    #Calculation
    for r in g.query(query_all_elements):
        if str(r.y) in centrosGastos:
            centrosGastos[str(r.y)] += float(r.z)
        else:
            centrosGastos[str(r.y)] = float(r.z)
    totalGastos=int(sum(centrosGastos.values()))

    #QUERY TO OBTAIN INGRESOS OF EACH CENTRO
    query_all_elements = prepareQuery('''
        SELECT DISTINCT ?z ?y
        WHERE
        {
        ?x <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://group10.com/ontology/Ingresos>.
        ?x <http://group10.com/ontology/tieneCentro> ?y.
        ?x <http://purl.org/cerif/frapo/hasMonetaryValue> ?z
        }
    '''
    )

    centrosIngresos = {}
    #Calculation
    for r in g.query(query_all_elements):
        if str(r.y) in centrosIngresos:
            centrosIngresos[str(r.y)] += float(r.z)
        else:
            centrosIngresos[str(r.y)] = float(r.z)
    totalIngresos=int(sum(centrosIngresos.values()))

    ##Query to select the coordenates and description for each seccion that has a longitude and latitude (the districts)
    query_all_elements = prepareQuery('''
        SELECT DISTINCT ?x ?y
        WHERE
    {
    ?x <http://group10.com/ontology/tieneCoordenadas> ?y

    }
    '''
    )
    distCor = {}
    path="http://group10.com/resource/Seccion/"
    espacios="%20"
    #Calculation
    for r in g.query(query_all_elements):
        if str(r.y) in distCor:
            pass
        if str(r.y) == "":
            pass
        else:
            distCor[str(r.x).replace(path,"").replace(espacios," ")] = str(r.y) ##Coordinates as strings
    districts = {}
    for key, value in distCor.items():
        coor = value.split(',')
        districts.setdefault(key,[]).append(float(coor[0]))
        districts.setdefault(key,[]).append(float(coor[1]))
    
    ##Query to select the sum of all of the gastos for each seccion that has a longitude and latitude (the districts)
    query_all_elements1 = prepareQuery('''
        SELECT DISTINCT ?x ?z ?y
        WHERE
        {
        ?x <http://purl.org/cerif/frapo/hasCost> ?z.
        ?x <http://group10.com/ontology/tieneSeccion> ?y.
        }
    '''

    )
    query_all_elements2 = prepareQuery('''
        SELECT DISTINCT ?x ?y
        WHERE
    {
    ?x <http://group10.com/ontology/tieneCoordenadas> ?y.

    }
    '''
    )                                 

    DistritosCoordenada=[]
    for r in g.query(query_all_elements2):
        if str(r.y)=="":
            pass
        else:
            DistritosCoordenada.append(str(r.x).replace(path,"").replace("%20"," "))
            
    DistGastos={}
    for r in g.query(query_all_elements1):
        for s in DistritosCoordenada:
            if(str(r.y)==s):
                if str(r.y) in DistGastos:
                    DistGastos[str(r.y)] += float(r.z)
                else:
                    DistGastos[str(r.y)] = float(r.z)

    for key, value in DistGastos.items():
        districts[key].append(int(value))
        districts[key].append(int(value/50000))
    totalGastosSeccionDist=int(sum(DistGastos.values()))  

    ##Query to select the population for each seccion that has a longitude and latitude (the districts)
    query_all_elements = prepareQuery('''
        SELECT DISTINCT ?x ?y
        WHERE
    {
    ?x <http://group10.com/ontology/tienePoblacion> ?y

    }
    '''
    )

    distPop = {}
    path="http://group10.com/resource/Seccion/"
    espacios="%20"
    #Calculation
    for r in g.query(query_all_elements):
        if str(r.y) in distPop:
            pass
        if str(r.y) == "":
            pass
        else:
            distPop[str(r.x).replace(path,"").replace(espacios," ")] = float(r.y) ##Coordinates as strings
    for key, value in distPop.items():
        districts[key].append(int(value))
        districts[key].append(int(value/250))
    totalPop=int(sum(distPop.values()))  

    #Query to select the sum of 
    ##all the gastos for each seccion that does not have a longitude or latitude

    query_all_elements1 = prepareQuery('''
        SELECT DISTINCT ?x ?z ?y
        WHERE
        {
        ?x <http://purl.org/cerif/frapo/hasCost> ?z.
        ?x <http://group10.com/ontology/tieneSeccion> ?y.
        }
    '''

    )
    query_all_elements2 = prepareQuery('''
        SELECT DISTINCT ?x ?y
        WHERE
    {
    ?x <http://group10.com/ontology/tieneCoordenadas> ?y.

    }
    '''
    )    

    DistritosinCoordenada=[]
    seccionGastos={}
    for r in g.query(query_all_elements2):
        if str(r.y)!="":
            pass
        else:
            DistritosinCoordenada.append(str(r.x).replace(path,"").replace("%20"," ").replace("%2C",","))

    for r in g.query(query_all_elements1):
        if str(r.y) in DistritosinCoordenada:
            if str(r.y) in seccionGastos:
                seccionGastos[str(r.y)] += float(r.z)
            else:
                seccionGastos[str(r.y)] = float(r.z)
    totalGastosSeccionNoDist=int(sum(seccionGastos.values()))       
    context = {
        "districts" : districts,
        "centrosGastos" : centrosGastos,
        "centrosIngresos" : centrosIngresos,
        "totalGastos" : totalGastos,
        "totalIngresos" : totalIngresos,
        "seccionGastos" : seccionGastos,
        "totalGastosSeccionNoDist" : totalGastosSeccionNoDist,
        "totalGastosSeccionDist" : totalGastosSeccionDist,
        "totalPop" : totalPop,
    }
    return render(request, 'odkg/home.html', context)
