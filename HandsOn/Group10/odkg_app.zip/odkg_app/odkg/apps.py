from django.apps import AppConfig


class ODKGConfig(AppConfig):
    name = 'odkg'
